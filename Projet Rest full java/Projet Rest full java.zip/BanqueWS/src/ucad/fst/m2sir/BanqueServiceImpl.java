package ucad.fst.m2sir;

import java.util.List;


import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlElement;

import ucad.fst.m2sir.metier.Invalidenum;


@WebService(endpointInterface="ucad.fst.m2sir.BanqueService")
public class BanqueServiceImpl implements BanqueService{
	
	
	private List <Compte> cptes;
	
	@XmlElement(name="montant")
	@WebMethod(operationName="EuroToCfa")
	public double conversion(double mt) {
		// TODO Auto-generated method stub
		return mt*655;
	}

	@XmlElement(name="montant")
	public Compte getCompte(long cpt) throws Invalidenum{
		int obj=999;
		for(int i=0;i<cptes.size();i++){
			if(cptes.get(i).getNumero()==cpt) obj=i;
		}
		if(obj==999) {
			throw new Invalidenum("Invalide num�ro"," le compte "+cptes +" n'exite pas");
		}
		return cptes.get(obj);
		}

	@XmlElement(name="compte")
	public List<Compte> getCompte() {
		// TODO Auto-generated method stub
		return cptes;
	}

}
