package ucad.fst.m2sir.metier;

public class Invalidenum extends Exception {
	private String erreurDetails;

	public Invalidenum(String raison, String erreurDetails) {

		super(raison);

		this.erreurDetails = erreurDetails;

	}

	public String getErreurDtails(){

		return erreurDetails;

	}
}