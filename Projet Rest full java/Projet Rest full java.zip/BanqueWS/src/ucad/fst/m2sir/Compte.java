package ucad.fst.m2sir;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="compte")
@XmlAccessorType(XmlAccessType.FIELD)
public class Compte implements Serializable{
	
	private long numero;
	private double solde;
	private Date datecreation;
	
	public Compte (Long n, double s, Date d) {
		this.numero=n;
		this.solde=s;
		this.datecreation=d;
	}
	
	public Compte() {}
	
	public Compte(Long n,double s) {
		this(n, s, new Date());
	}

	public double getSolde() {
		return solde;
	}

	public long getNumero() {
		// TODO Auto-generated method stub
		return numero;
	}
}
