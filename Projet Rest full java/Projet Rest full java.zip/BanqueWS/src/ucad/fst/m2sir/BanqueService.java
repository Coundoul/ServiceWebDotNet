package ucad.fst.m2sir;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

import ucad.fst.m2sir.metier.Invalidenum;


@WebService
public interface BanqueService {
	
	@WebMethod(operationName="Conversion Fcfa TO Euro")
	public double conversion(@WebParam(name="Montant") double m);
	@WebMethod
	public Compte getCompte(@WebParam(name="Numero Compte") long n) throws Invalidenum;
	@WebMethod
	public List <Compte> getCompte();
}
