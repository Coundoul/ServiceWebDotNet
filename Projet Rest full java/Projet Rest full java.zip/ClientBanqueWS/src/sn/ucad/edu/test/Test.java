package sn.ucad.edu.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;



public class Test {

	public static void main(String[] args) throws ClientProtocolException, IOException {
		
		HttpClient httpClient = HttpClientBuilder.create().build();
		HttpGet getRequest = new HttpGet("http://10.153.93.235:8080/BanqueRsDyn/rs/comptes");
		getRequest.addHeader("accept", "application/xml");
		HttpResponse response = httpClient.execute(getRequest);
		
		if (response.getStatusLine().getStatusCode() != 200) {
		throw new RuntimeException("Failed : HTTP error code : " +
		response.getStatusLine().getStatusCode());
		}
		
		BufferedReader br = new BufferedReader(new
		InputStreamReader((response.getEntity().getContent())));
		String output;
		while ((output = br.readLine()) != null) {
		System.out.println(output);
			}
		}

}
