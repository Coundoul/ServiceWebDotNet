package naldo.test.api;

import java.io.IOException;


import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.json.JSONConfiguration;
import com.sun.jersey.json.impl.provider.entity.JSONObjectProvider;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import naldo.test.entities.Orders;

public class ClientJavaToDotNetApi extends Application {

	public static void main(String[] args) throws JsonParseException, JsonMappingException, IOException {
		// TODO Auto-generated method stub
		launch(args);
	}

	public static void addOrders(Orders orders) throws JsonParseException, JsonMappingException, IOException {

		ClientConfig clientConfig = new DefaultClientConfig();

		clientConfig.getFeatures().put(JSONConfiguration.FEATURE_POJO_MAPPING, Boolean.TRUE);

		Client client = Client.create(clientConfig);

		URI uri = UriBuilder.fromUri("https://localhost:44308/").build();

		ObjectMapper mapper = new ObjectMapper();

		// INSERTION D'UNE COMMANDE
		ClientResponse resp2 = client.resource(uri).path("api").path("Ordersapi").accept(MediaType.APPLICATION_JSON)
				.type(MediaType.APPLICATION_JSON).post(ClientResponse.class, mapper.writeValueAsString(orders));

		System.out.println(resp2.getEntity(String.class));

	}

	public List<Integer> getAllOrdersID() throws JsonParseException, JsonMappingException, IOException {
		ClientConfig clientConfig = new DefaultClientConfig();

		clientConfig.getFeatures().put(JSONConfiguration.FEATURE_POJO_MAPPING, Boolean.TRUE);

		Client client = Client.create(clientConfig);

		URI uri = UriBuilder.fromUri("https://localhost:44308/").build();

		ObjectMapper mapper = new ObjectMapper();
		
		ClientResponse response = client.resource(uri).path("api").path("Ordersapi").get(ClientResponse.class);

		String corpsRespHttp = response.getEntity(String.class);

		System.out.println("Corps reponse http" + corpsRespHttp);
		
		List<Integer> ordersIDList = new ArrayList<Integer>();

		Orders[] orders1 = mapper.readValue(corpsRespHttp, Orders[].class);

		for (Orders od : orders1) {
			System.out.println("OrderID: " + od.getOrderID());
			ordersIDList.add(od.getOrderID()) ;
		}

		return ordersIDList ;
		
	}
	
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		primaryStage.setTitle("AJOUT D'UNE COMMANDE");

		BorderPane borderPane = new BorderPane();
		Scene scene = new Scene(borderPane, 400, 400);
		primaryStage.setScene(scene);

		// CREATION DE 4 HBox
		HBox hBox1 = new HBox(); hBox1.setPadding(new Insets(5)); hBox1.setSpacing(10);
		HBox hBox2 = new HBox(); hBox2.setPadding(new Insets(5)); hBox2.setSpacing(10);
		HBox hBox3 = new HBox(); hBox3.setPadding(new Insets(5)); hBox3.setSpacing(10);
		HBox hBox4 = new HBox(); hBox4.setPadding(new Insets(5)); hBox4.setSpacing(10);

		// AJOUT DE 3 LABLES ET DE 3 TEXTFIELD
		Label lblCustomerId = new Label("CustomerID: "); TextField txtCustomerID = new TextField();
		Label lblEmoloyeId = new Label("EmployeID : "); TextField txtEmoloyeId = new TextField();
		Label lblShipVia = new Label("ShipVia      : "); TextField txtShipVia = new TextField();
		Button btnsave = new Button("ENREGISTRER");

		// AJOUT DES LABEL ET TEXTFIELD DANS LES HBOX
		hBox1.getChildren().addAll(lblCustomerId, txtCustomerID);
		hBox2.getChildren().addAll(lblEmoloyeId, txtEmoloyeId);
		hBox3.getChildren().addAll(lblShipVia, txtShipVia);
		hBox4.getChildren().addAll(btnsave);

		// CREATION DU VBox QUI VA CONTENIR LES 4 HBOX CREER CI-DESSUS
		VBox vBox1 = new VBox();// vBox1.setPadding(new Insets(10));
		vBox1.getChildren().addAll(hBox1, hBox2, hBox3, hBox4);
		borderPane.setTop(vBox1);

		// AJOUT D'UN VBOX DEUXIEME POUR AFFICHER LA LISTE DES NUMERO DE COMMANDES
		VBox vBox2 = new VBox(); vBox2.setPadding(new Insets(10));
		ObservableList<String> observableList = FXCollections.observableArrayList();
		ListView<String> listView1 = new ListView<>(observableList);
		
		// RECUPERATION DE LA LISTE DES NUMERO DE COMMANDES DANS LA LISTE D'OBSERVABLE
		List<Integer> ordersID = new ArrayList<Integer>() ;
		ordersID = this.getAllOrdersID();
		for(Integer i: ordersID) {
			observableList.addAll(String.valueOf(i));
		}
		
		vBox2.getChildren().addAll(listView1);
		borderPane.setCenter(vBox2);

		// CREATION D'UN MESSAGE D'ALERTE D'INFORMATION
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Information Commande"); alert.setHeaderText(null); 
		alert.setContentText("La Commande a ete ajoute avec succees");
		
		// ENREGISTREMENT DES COMMANDES LORSQUE L'UTILISATEUR CLICK SUR LE BOUTON ENREGISTRER
		btnsave.setOnAction(e -> {
			if (!(txtCustomerID.getText().isEmpty()) && !(txtEmoloyeId.getText().isEmpty())
					&& !(txtShipVia.getText().isEmpty())) {
				Orders od1 = new Orders(txtCustomerID.getText());
				od1.setEmployeeID(Integer.parseInt(txtEmoloyeId.getText()));
				od1.setShipVia(Integer.parseInt(txtShipVia.getText()));
				try {
					addOrders(od1);
					alert.showAndWait(); // on affiche le message d'alerte
					// on met a jour la listView
					List<Integer> ordersID2 = new ArrayList<Integer>() ;
					ordersID2 = this.getAllOrdersID();
					for(Integer i: ordersID2) {
						observableList.addAll(String.valueOf(i));
					}
				} catch (IOException e1) {
					e1.printStackTrace();
				}

			}

		});

		primaryStage.show();
	}
}
