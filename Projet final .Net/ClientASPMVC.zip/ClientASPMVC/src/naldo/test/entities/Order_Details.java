package naldo.test.entities;

public class Order_Details {

}
