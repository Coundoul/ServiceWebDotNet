package naldo.test.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

//@XmlRootElement
//@JsonIgnoreProperties(ignoreUnknown = true)
public class Orders implements Serializable{
	
	@JsonProperty
	 private int OrderID  ;
	@JsonProperty
     private String CustomerID  ;
	@JsonProperty
     private int EmployeeID  ;
	@JsonProperty
     private Date OrderDate ;
	@JsonProperty
     private Date RequiredDate ;
	@JsonProperty
     private Date ShippedDate ;
	@JsonProperty
     private int ShipVia ;
	@JsonProperty
     private double Freight ;
	@JsonProperty
     private String ShipName  ;
	@JsonProperty
     private String ShipAddress ;
	@JsonProperty
     private String ShipCity ;
	@JsonProperty
     private String ShipRegion ;
	@JsonProperty
     private String ShipPostalCode ;
	@JsonProperty
     private String ShipCountry ;
	@JsonProperty
     private Customers Customers ;
	@JsonProperty
     private List<Order_Details> Order_Details;
     
     public Orders() {
 		super();
 		// TODO Auto-generated constructor stub
 	}
     public Orders(String customerID) {
    	 super();
  		CustomerID = customerID ;
  	}

	public Orders(int orderID, String customerID, int employeeID, Date orderDate, Date requiredDate, Date shippedDate,int shipVia, 
			double freight, String shipName, String shipAddress, String shipCity, String shipRegion,String shipPostalCode, 
			String shipCountry, naldo.test.entities.Customers customers,
			List<naldo.test.entities.Order_Details> order_Details) {
		super();
		OrderID = orderID;
		CustomerID = customerID;
		EmployeeID = employeeID;
		OrderDate = orderDate;
		RequiredDate = requiredDate;
		ShippedDate = shippedDate;
		ShipVia = shipVia;
		Freight = freight;
		ShipName = shipName;
		ShipAddress = shipAddress;
		ShipCity = shipCity;
		ShipRegion = shipRegion;
		ShipPostalCode = shipPostalCode;
		ShipCountry = shipCountry;
		Customers = customers;
		Order_Details = order_Details;
	}
	
	public int getOrderID() {
		return OrderID;
	}

	public void setOrderID(int orderID) {
		OrderID = orderID;
	}

	public String getCustomerID() {
		return CustomerID;
	}

	public void setCustomerID(String customerID) {
		CustomerID = customerID;
	}

	public int getEmployeeID() {
		return EmployeeID;
	}

	public void setEmployeeID(int employeeID) {
		EmployeeID = employeeID;
	}

	public Date getOrderDate() {
		return OrderDate;
	}

	public void setOrderDate(Date orderDate) {
		OrderDate = orderDate;
	}

	public Date getRequiredDate() {
		return RequiredDate;
	}

	public void setRequiredDate(Date requiredDate) {
		RequiredDate = requiredDate;
	}

	public Date getShippedDate() {
		return ShippedDate;
	}

	public void setShippedDate(Date shippedDate) {
		ShippedDate = shippedDate;
	}

	public int getShipVia() {
		return ShipVia;
	}

	public void setShipVia(int shipVia) {
		ShipVia = shipVia;
	}

	public double getFreight() {
		return Freight;
	}

	public void setFreight(double freight) {
		Freight = freight;
	}

	public String getFhipName() {
		return ShipName;
	}

	public void setFhipName(String fhipName) {
		ShipName = fhipName;
	}

	public String getShipAddress() {
		return ShipAddress;
	}

	public void setShipAddress(String shipAddress) {
		ShipAddress = shipAddress;
	}

	public String getShipCity() {
		return ShipCity;
	}

	public void setShipCity(String shipCity) {
		ShipCity = shipCity;
	}

	public String getShipRegion() {
		return ShipRegion;
	}

	public void setShipRegion(String shipRegion) {
		ShipRegion = shipRegion;
	}

	public String getShipPostalCode() {
		return ShipPostalCode;
	}

	public void setShipPostalCode(String shipPostalCode) {
		ShipPostalCode = shipPostalCode;
	}

	public String getShipCountry() {
		return ShipCountry;
	}

	public void setShipCountry(String shipCountry) {
		ShipCountry = shipCountry;
	}

	public Customers getCustomers() {
		return Customers;
	}

	public void setCustomers(Customers customers) {
		Customers = customers;
	}

	public List<Order_Details> getOrder_Details() {
		return Order_Details;
	}

	public void setOrder_Details(List<Order_Details> order_Details) {
		Order_Details = order_Details;
	}
		    

}
