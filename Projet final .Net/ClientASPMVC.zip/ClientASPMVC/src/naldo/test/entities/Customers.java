package naldo.test.entities;

public class Customers {

}
